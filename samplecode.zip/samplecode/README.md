# AWS Resource Comparator

A Flask web application that compares AWS resources between two accounts using tagging API and provides an interactive HTML report with drill-down capabilities.

## Features

- Compare resources between two AWS accounts using tag filters
- Interactive HTML report with expandable resource details
- Drill down into resource dependencies (Lambda triggers, ALB listeners, Security Group rules, etc.)
- Support for multiple AWS services: Lambda, S3, ALB, API Gateway, EC2
- Real-time resource detail loading
- Bootstrap-based responsive UI

## Prerequisites

1. **AWS CLI configured** with profiles for both accounts
2. **Python 3.7+**
3. **Required AWS permissions** for both accounts:
   - `resourcegroupstaggingapi:GetResources`
   - Service-specific read permissions:
     - `lambda:GetFunction`
     - `lambda:GetPolicy`
     - `lambda:ListEventSourceMappings`
     - `s3:GetBucketLocation`
     - `s3:GetBucketPolicy`
     - `s3:GetBucketVersioning`
     - `elasticloadbalancing:DescribeLoadBalancers`
     - `elasticloadbalancing:DescribeListeners`
     - `elasticloadbalancing:DescribeTargetGroups`
     - `apigateway:GET`
     - `ec2:DescribeInstances`
     - `ec2:DescribeSecurityGroups`

## Setup

1. **Clone or create the project directory:**
   ```bash
   mkdir aws-resource-comparator
   cd aws-resource-comparator
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure AWS profiles:**
   ```bash
   aws configure --profile account-a
   aws configure --profile account-b
   ```

4. **Run the application:**
   ```bash
   python app.py
   ```

5. **Access the web interface:**
   Open your browser and go to `http://localhost:5000`

## Usage

1. **Enter AWS Profile Names:**
   - Source Account Profile: The AWS CLI profile for your source account
   - Target Account Profile: The AWS CLI profile for your target account

2. **Specify Tag Filter:**
   - Tag Key: The tag key to filter resources (default: "Component")
   - Tag Value: The tag value to filter resources (default: "testing")

3. **Generate Report:**
   - Click "Generate Comparison Report"
   - Wait for the analysis to complete

4. **Explore the Report:**
   - View summary statistics
   - Click on any resource to expand and see detailed information
   - Drill down into dependencies like security groups, triggers, etc.

## Supported AWS Services

- **Lambda Functions:** Configuration, triggers, VPC settings, security groups
- **Application Load Balancers:** Listeners, target groups, security groups
- **S3 Buckets:** Location, policies, versioning
- **API Gateway:** REST APIs, resources, stages
- **EC2 Instances:** Instance details, security groups

## Report Features

### Summary View
- Total resource counts per account
- Common services between accounts
- Services unique to each account

### Resource Details
- **Lambda Functions:**
  - Runtime, memory, timeout configuration
  - Event source mappings and triggers
  - VPC configuration and security groups

- **Load Balancers:**
  - Type, scheme, state information
  - Listener configurations
  - Security group rules with inbound/outbound traffic

- **S3 Buckets:**
  - Region and versioning status
  - Bucket policies (if any)

- **Security Groups:**
  - Detailed inbound and outbound rules
  - Protocol, port, and source/destination information

## File Structure

```
aws-resource-comparator/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── README.md             # This file
└── templates/
    ├── base.html         # Base template
    ├── index.html        # Main form page
    └── report.html       # Interactive report page
```

## Troubleshooting

1. **AWS Profile Issues:**
   - Ensure profiles are configured: `aws configure list-profiles`
   - Test profile access: `aws sts get-caller-identity --profile your-profile`

2. **Permission Errors:**
   - Verify IAM permissions for the Resource Groups Tagging API
   - Check service-specific permissions

3. **No Resources Found:**
   - Verify tag key and value exist on resources
   - Check if resources are in the expected regions

4. **Resource Details Not Loading:**
   - Check browser console for JavaScript errors
   - Verify service-specific permissions

## Extending the Application

To add support for additional AWS services:

1. Add a new method in the `AWSResourceComparator` class (e.g., `_get_rds_details`)
2. Update the `get_resource_details` method to handle the new service
3. Add rendering logic in the `report.html` template

## Security Notes

- This application requires read-only access to AWS resources
- Ensure AWS credentials are properly secured
- Consider running in a secure environment for production use
- The application stores comparison data temporarily in browser session storage