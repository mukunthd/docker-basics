#!/usr/bin/env python3
"""
Startup script for corporate/financial environments with SSL/firewall issues
"""

import os
import sys

def setup_corporate_environment():
    """Configure environment for corporate firewalls and SSL issues"""
    
    print("Setting up corporate environment configuration...")
    
    # Disable SSL verification for corporate environments
    os.environ['DISABLE_SSL_VERIFICATION'] = 'true'
    os.environ['PYTHONHTTPSVERIFY'] = '0'
    
    # Additional SSL/TLS configurations (no proxy needed)
    os.environ['SSL_VERIFY'] = 'false'
    os.environ['REQUESTS_CA_BUNDLE'] = ''
    os.environ['CURL_CA_BUNDLE'] = ''
    
    print("✅ SSL verification disabled")
    print("✅ Environment configured for corporate networks")
    print("ℹ️  No proxy configuration needed")
    print()
    
    # Import and run the main application
    try:
        from app import app
        print("🚀 Starting AWS Resource Comparator...")
        print("� Accetss the application at: http://localhost:5000")
        print("⚠️  Note: SSL verification is disabled for corporate environment")
        print()
        
        app.run(debug=True, host='0.0.0.0', port=5000)
        
    except ImportError as e:
        print(f"❌ Error importing app: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error starting application: {e}")
        sys.exit(1)

if __name__ == '__main__':
    setup_corporate_environment()