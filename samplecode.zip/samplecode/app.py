from flask import Flask, render_template, request, jsonify
import boto3
import json
from datetime import datetime
from collections import defaultdict
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

class AWSResourceComparator:
    def __init__(self, profile_a, profile_b, regions=None):
        """Initialize with AWS profiles for both accounts"""
        self.profile_a = profile_a
        self.profile_b = profile_b
        self.regions = regions or ['us-east-1', 'us-west-2', 'eu-west-1']  # Default regions
        
        # We'll create sessions per region as needed, but test credentials first
        try:
            # Test credentials for both profiles with explicit region
            test_session_a = boto3.Session(profile_name=profile_a, region_name=self.regions[0])
            test_session_b = boto3.Session(profile_name=profile_b, region_name=self.regions[0])
            
            # Validate credentials
            self._validate_credentials(test_session_a, test_session_b)
            
        except Exception as e:
            logging.error(f"Failed to initialize AWS sessions: {e}")
            raise Exception(f"AWS credential error: {e}")
    
    def _validate_credentials(self, session_a, session_b):
        """Validate that both AWS profiles have valid credentials"""
        try:
            # Test profile A
            sts_a = session_a.client('sts')
            identity_a = sts_a.get_caller_identity()
            logging.info(f"Profile {self.profile_a} - Account: {identity_a.get('Account')}, User: {identity_a.get('Arn')}")
            
            # Test profile B
            sts_b = session_b.client('sts')
            identity_b = sts_b.get_caller_identity()
            logging.info(f"Profile {self.profile_b} - Account: {identity_b.get('Account')}, User: {identity_b.get('Arn')}")
            
            if identity_a.get('Account') == identity_b.get('Account'):
                logging.warning("Both profiles appear to be using the same AWS account!")
                
        except Exception as e:
            logging.error(f"Credential validation failed: {e}")
            raise Exception(f"Invalid AWS credentials for profiles {self.profile_a} or {self.profile_b}: {e}")
    
    def _get_session(self, profile, region):
        """Get a boto3 session for a specific profile and region"""
        return boto3.Session(profile_name=profile, region_name=region)
        
    def get_tagged_resources(self, profile, tag_key, tag_value):
        """Get all resources with specific tag from an account across multiple regions"""
        all_resources = []
        
        for region in self.regions:
            try:
                # Create session with explicit profile and region
                session = self._get_session(profile, region)
                resource_groups_client = session.client('resourcegroupstaggingapi')
                resources = []
                
                paginator = resource_groups_client.get_paginator('get_resources')
                for page in paginator.paginate(
                    TagFilters=[
                        {
                            'Key': tag_key,
                            'Values': [tag_value]
                        }
                    ]
                ):
                    resources.extend(page['ResourceTagMappingList'])
                
                # Add region info to each resource for tracking
                for resource in resources:
                    resource['Region'] = region
                
                all_resources.extend(resources)
                logging.info(f"Found {len(resources)} resources in region {region} for profile {profile}")
                
            except Exception as e:
                logging.error(f"Error fetching resources from region {region} for profile {profile}: {e}")
                continue
                
        return all_resources
    
    def get_resource_details(self, profile, resource_arn):
        """Get detailed information about a specific resource"""
        try:
            service = resource_arn.split(':')[2]
            region = resource_arn.split(':')[3]
            resource_id = resource_arn.split('/')[-1]
            
            # Handle S3 which doesn't have region in ARN
            if service == 's3':
                region = 'us-east-1'  # S3 API calls typically go to us-east-1
            elif not region:
                region = 'us-east-1'  # Default region if not specified
            
            logging.info(f"Getting details for {service} resource in region {region} using profile {profile}")
            
            # Create session with explicit profile and region
            session = self._get_session(profile, region)
            
            # Test session credentials before making service calls
            try:
                sts = session.client('sts')
                identity = sts.get_caller_identity()
                logging.info(f"Using credentials for account: {identity.get('Account')}")
            except Exception as e:
                logging.error(f"Credential validation failed: {e}")
                return {"error": f"Invalid AWS credentials: {e}"}
            
            if service == 'lambda':
                return self._get_lambda_details(session, resource_arn, region)
            elif service == 's3':
                return self._get_s3_details(session, resource_arn)
            elif service == 'elasticloadbalancing':
                return self._get_alb_details(session, resource_arn, region)
            elif service == 'apigateway':
                return self._get_apigateway_details(session, resource_arn, region)
            elif service == 'ec2':
                return self._get_ec2_details(session, resource_arn, region)
            else:
                return {"error": f"Service {service} not supported yet"}
                
        except Exception as e:
            logging.error(f"Error getting details for {resource_arn}: {e}", exc_info=True)
            return {"error": str(e)}
    
    def _get_lambda_details(self, session, resource_arn, region):
        """Get Lambda function details including triggers"""
        lambda_client = session.client('lambda', region_name=region)
        function_name = resource_arn.split(':')[-1]
        
        try:
            # Get function configuration
            function_config = lambda_client.get_function(FunctionName=function_name)
            
            # Get event source mappings (triggers)
            event_sources = lambda_client.list_event_source_mappings(FunctionName=function_name)
            
            # Get function policy to identify other triggers
            try:
                policy = lambda_client.get_policy(FunctionName=function_name)
                policy_doc = json.loads(policy['Policy'])
            except:
                policy_doc = None
            
            return {
                "type": "lambda",
                "config": function_config['Configuration'],
                "code": function_config.get('Code', {}),
                "triggers": event_sources['EventSourceMappings'],
                "policy": policy_doc,
                "dependencies": self._get_lambda_dependencies(session, function_config, region)
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _get_lambda_dependencies(self, session, function_config, region):
        """Get Lambda dependencies like VPC, security groups, etc."""
        dependencies = {}
        
        # VPC Configuration
        if 'VpcConfig' in function_config['Configuration']:
            vpc_config = function_config['Configuration']['VpcConfig']
            if vpc_config.get('SecurityGroupIds'):
                sg_details = self._get_security_group_details(
                    session, vpc_config['SecurityGroupIds'], region
                )
                # Ensure we always return an array, even if there's an error
                dependencies['security_groups'] = sg_details if isinstance(sg_details, list) else []
            else:
                dependencies['security_groups'] = []
            
            if vpc_config.get('SubnetIds'):
                dependencies['subnets'] = vpc_config['SubnetIds']
        else:
            dependencies['security_groups'] = []
        
        return dependencies
    
    def _get_security_group_details(self, session, sg_ids, region):
        """Get security group details and rules"""
        ec2_client = session.client('ec2', region_name=region)
        
        try:
            response = ec2_client.describe_security_groups(GroupIds=sg_ids)
            return response['SecurityGroups']
        except Exception as e:
            logging.error(f"Error getting security group details: {e}")
            return []  # Return empty array instead of error object
    
    def _get_alb_details(self, session, resource_arn, region):
        """Get ALB details including listeners and target groups"""
        elbv2_client = session.client('elbv2', region_name=region)
        
        try:
            # Get load balancer details
            lb_response = elbv2_client.describe_load_balancers(LoadBalancerArns=[resource_arn])
            lb_details = lb_response['LoadBalancers'][0]
            
            # Get listeners
            listeners = elbv2_client.describe_listeners(LoadBalancerArn=resource_arn)
            
            # Get target groups
            target_groups = elbv2_client.describe_target_groups(LoadBalancerArn=resource_arn)
            
            # Get security groups
            sg_details = []
            if lb_details.get('SecurityGroups'):
                sg_details = self._get_security_group_details(
                    session, lb_details['SecurityGroups'], region
                )
                # Ensure it's always an array
                if not isinstance(sg_details, list):
                    sg_details = []
            
            return {
                "type": "alb",
                "details": lb_details,
                "listeners": listeners['Listeners'],
                "target_groups": target_groups['TargetGroups'],
                "security_groups": sg_details
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _get_s3_details(self, session, resource_arn):
        """Get S3 bucket details"""
        s3_client = session.client('s3')
        bucket_name = resource_arn.split(':')[-1]
        
        try:
            # Get bucket location
            location = s3_client.get_bucket_location(Bucket=bucket_name)
            
            # Get bucket policy
            try:
                policy = s3_client.get_bucket_policy(Bucket=bucket_name)
                policy_doc = json.loads(policy['Policy'])
            except:
                policy_doc = None
            
            # Get bucket versioning
            try:
                versioning = s3_client.get_bucket_versioning(Bucket=bucket_name)
            except:
                versioning = None
            
            return {
                "type": "s3",
                "bucket_name": bucket_name,
                "location": location,
                "policy": policy_doc,
                "versioning": versioning
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _get_apigateway_details(self, session, resource_arn, region):
        """Get API Gateway details"""
        apigateway_client = session.client('apigateway', region_name=region)
        api_id = resource_arn.split('/')[-1]
        
        try:
            # Get REST API details
            api_details = apigateway_client.get_rest_api(restApiId=api_id)
            
            # Get resources
            resources = apigateway_client.get_resources(restApiId=api_id)
            
            # Get stages
            stages = apigateway_client.get_stages(restApiId=api_id)
            
            return {
                "type": "apigateway",
                "api_details": api_details,
                "resources": resources['items'],
                "stages": stages['item']
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _get_ec2_details(self, session, resource_arn, region):
        """Get EC2 instance details"""
        ec2_client = session.client('ec2', region_name=region)
        instance_id = resource_arn.split('/')[-1]
        
        try:
            response = ec2_client.describe_instances(InstanceIds=[instance_id])
            instance = response['Reservations'][0]['Instances'][0]
            
            # Get security group details
            sg_details = []
            if instance.get('SecurityGroups'):
                sg_ids = [sg['GroupId'] for sg in instance['SecurityGroups']]
                sg_details = self._get_security_group_details(session, sg_ids, region)
                # Ensure it's always an array
                if not isinstance(sg_details, list):
                    sg_details = []
            
            return {
                "type": "ec2",
                "instance": instance,
                "security_groups": sg_details
            }
        except Exception as e:
            return {"error": str(e)}
    
    def compare_resources(self, tag_key, tag_value):
        """Compare resources between two accounts"""
        # Get resources from both accounts
        resources_a = self.get_tagged_resources(self.profile_a, tag_key, tag_value)
        resources_b = self.get_tagged_resources(self.profile_b, tag_key, tag_value)
        
        # Organize by service type
        comparison = {
            "account_a": {
                "profile": self.profile_a,
                "resources": self._organize_by_service(resources_a)
            },
            "account_b": {
                "profile": self.profile_b,
                "resources": self._organize_by_service(resources_b)
            },
            "summary": self._generate_summary(resources_a, resources_b)
        }
        
        return comparison
    
    def _organize_by_service(self, resources):
        """Organize resources by AWS service"""
        organized = defaultdict(list)
        
        for resource in resources:
            arn = resource['ResourceARN']
            service = arn.split(':')[2]
            region = resource.get('Region', arn.split(':')[3] if len(arn.split(':')) > 3 else 'global')
            
            organized[service].append({
                "arn": arn,
                "region": region,
                "tags": {tag['Key']: tag['Value'] for tag in resource['Tags']}
            })
        
        return dict(organized)
    
    def _generate_summary(self, resources_a, resources_b):
        """Generate comparison summary"""
        services_a = set(res['ResourceARN'].split(':')[2] for res in resources_a)
        services_b = set(res['ResourceARN'].split(':')[2] for res in resources_b)
        
        regions_a = set(res.get('Region', 'unknown') for res in resources_a)
        regions_b = set(res.get('Region', 'unknown') for res in resources_b)
        
        return {
            "total_resources_a": len(resources_a),
            "total_resources_b": len(resources_b),
            "services_a": list(services_a),
            "services_b": list(services_b),
            "regions_a": list(regions_a),
            "regions_b": list(regions_b),
            "common_services": list(services_a & services_b),
            "only_in_a": list(services_a - services_b),
            "only_in_b": list(services_b - services_a),
            "common_regions": list(regions_a & regions_b),
            "regions_only_in_a": list(regions_a - regions_b),
            "regions_only_in_b": list(regions_b - regions_a)
        }

# Flask routes
@app.route('/')
def index():
    """Main page with form to input parameters"""
    return render_template('index.html')

@app.route('/diagnostics')
def diagnostics():
    """Diagnostic information about the environment"""
    import os
    import configparser
    
    try:
        # Check AWS CLI configuration
        aws_config_dir = os.path.expanduser('~/.aws')
        credentials_file = os.path.join(aws_config_dir, 'credentials')
        config_file = os.path.join(aws_config_dir, 'config')
        
        diagnostics_info = {
            "aws_config_dir_exists": os.path.exists(aws_config_dir),
            "credentials_file_exists": os.path.exists(credentials_file),
            "config_file_exists": os.path.exists(config_file),
            "environment_variables": {
                "AWS_PROFILE": os.environ.get('AWS_PROFILE'),
                "AWS_DEFAULT_REGION": os.environ.get('AWS_DEFAULT_REGION'),
                "AWS_ACCESS_KEY_ID": "Set" if os.environ.get('AWS_ACCESS_KEY_ID') else "Not set",
                "AWS_SECRET_ACCESS_KEY": "Set" if os.environ.get('AWS_SECRET_ACCESS_KEY') else "Not set"
            }
        }
        
        # Parse credentials file
        credentials_profiles = []
        if os.path.exists(credentials_file):
            try:
                cred_config = configparser.ConfigParser()
                cred_config.read(credentials_file)
                credentials_profiles = list(cred_config.sections())
                
                # Show what's in each profile (without sensitive data)
                profile_details = {}
                for profile in credentials_profiles:
                    profile_details[profile] = {
                        "has_access_key": cred_config.has_option(profile, 'aws_access_key_id'),
                        "has_secret_key": cred_config.has_option(profile, 'aws_secret_access_key'),
                        "has_region": cred_config.has_option(profile, 'region'),
                        "region": cred_config.get(profile, 'region', fallback='Not set')
                    }
                diagnostics_info["credentials_profiles"] = profile_details
            except Exception as e:
                diagnostics_info["credentials_error"] = str(e)
        
        # Parse config file
        config_profiles = []
        if os.path.exists(config_file):
            try:
                aws_config = configparser.ConfigParser()
                aws_config.read(config_file)
                # Config file uses 'profile ' prefix for non-default profiles
                config_profiles = [section.replace('profile ', '') for section in aws_config.sections() 
                                 if section.startswith('profile ') or section == 'default']
                
                # Show config details
                config_details = {}
                for section in aws_config.sections():
                    profile_name = section.replace('profile ', '') if section.startswith('profile ') else section
                    config_details[profile_name] = {
                        "region": aws_config.get(section, 'region', fallback='Not set'),
                        "output": aws_config.get(section, 'output', fallback='Not set')
                    }
                diagnostics_info["config_profiles"] = config_details
            except Exception as e:
                diagnostics_info["config_error"] = str(e)
        
        diagnostics_info["available_profiles"] = list(set(credentials_profiles + config_profiles))
        
        # Recommendations
        recommendations = []
        if not credentials_profiles and not config_profiles:
            recommendations.append("No AWS profiles found. Run 'aws configure --profile <profile-name>' to set up profiles.")
        elif credentials_profiles and not config_profiles:
            recommendations.append("Profiles found in credentials file only. This should work fine.")
        elif config_profiles and not credentials_profiles:
            recommendations.append("Profiles found in config file only. You need credentials in ~/.aws/credentials file.")
        
        diagnostics_info["recommendations"] = recommendations
        
        return jsonify(diagnostics_info)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/test-credentials', methods=['POST'])
def test_credentials():
    """Test AWS credentials for both profiles"""
    data = request.get_json()
    
    profile_a = data.get('profile_a')
    profile_b = data.get('profile_b')
    
    if not profile_a or not profile_b:
        return jsonify({"error": "Both AWS profiles are required"}), 400
    
    try:
        # Test profile A with explicit region
        session_a = boto3.Session(profile_name=profile_a, region_name='us-east-1')
        sts_a = session_a.client('sts')
        identity_a = sts_a.get_caller_identity()
        
        # Test profile B with explicit region
        session_b = boto3.Session(profile_name=profile_b, region_name='us-east-1')
        sts_b = session_b.client('sts')
        identity_b = sts_b.get_caller_identity()
        
        return jsonify({
            "success": True,
            "profile_a": {
                "profile": profile_a,
                "account": identity_a.get('Account'),
                "user": identity_a.get('Arn'),
                "user_id": identity_a.get('UserId')
            },
            "profile_b": {
                "profile": profile_b,
                "account": identity_b.get('Account'),
                "user": identity_b.get('Arn'),
                "user_id": identity_b.get('UserId')
            },
            "same_account": identity_a.get('Account') == identity_b.get('Account')
        })
        
    except Exception as e:
        logging.error(f"Credential test error: {e}")
        return jsonify({"error": f"Credential validation failed: {str(e)}"}), 500

@app.route('/compare', methods=['POST'])
def compare():
    """Generate comparison report"""
    data = request.get_json()
    
    profile_a = data.get('profile_a')
    profile_b = data.get('profile_b')
    tag_key = data.get('tag_key', 'Component')
    tag_value = data.get('tag_value', 'testing')
    regions = data.get('regions', ['us-east-1', 'us-west-2', 'eu-west-1'])
    
    if not profile_a or not profile_b:
        return jsonify({"error": "Both AWS profiles are required"}), 400
    
    try:
        comparator = AWSResourceComparator(profile_a, profile_b, regions)
        comparison_result = comparator.compare_resources(tag_key, tag_value)
        
        return jsonify({
            "success": True,
            "data": comparison_result,
            "timestamp": datetime.now().isoformat()
        })
    except Exception as e:
        logging.error(f"Comparison error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/resource-details')
def resource_details():
    """Get detailed information about a specific resource"""
    resource_arn = request.args.get('arn')
    profile = request.args.get('profile')
    
    logging.info(f"Resource details request - ARN: {resource_arn}, Profile: {profile}")
    
    if not resource_arn or not profile:
        logging.error("Missing required parameters")
        return jsonify({"error": "Resource ARN and profile are required"}), 400
    
    try:
        # Extract service and region from ARN
        service = resource_arn.split(':')[2]
        region = resource_arn.split(':')[3]
        
        # Handle S3 which doesn't have region in ARN
        if service == 's3':
            region = 'us-east-1'
        elif not region:
            region = 'us-east-1'
        
        logging.info(f"Getting details for {service} resource in region {region} using profile {profile}")
        
        # Create session with explicit profile and region
        session = boto3.Session(profile_name=profile, region_name=region)
        
        # Test session credentials
        try:
            sts = session.client('sts')
            identity = sts.get_caller_identity()
            logging.info(f"Using credentials for account: {identity.get('Account')}")
        except Exception as e:
            logging.error(f"Credential validation failed: {e}")
            return jsonify({"error": f"Invalid AWS credentials: {e}"}), 500
        
        # Create a temporary comparator instance for the helper methods
        comparator = AWSResourceComparator(profile, profile, [region])
        
        # Get resource details
        if service == 'lambda':
            details = comparator._get_lambda_details(session, resource_arn, region)
        elif service == 's3':
            details = comparator._get_s3_details(session, resource_arn)
        elif service == 'elasticloadbalancing':
            details = comparator._get_alb_details(session, resource_arn, region)
        elif service == 'apigateway':
            details = comparator._get_apigateway_details(session, resource_arn, region)
        elif service == 'ec2':
            details = comparator._get_ec2_details(session, resource_arn, region)
        else:
            details = {"error": f"Service {service} not supported yet"}
        
        logging.info(f"Resource details retrieved: {type(details)}")
        logging.debug(f"Details content: {details}")
        
        response = {
            "success": True,
            "data": details
        }
        
        logging.info(f"Sending response: success={response['success']}")
        return jsonify(response)
        
    except Exception as e:
        logging.error(f"Resource details error: {e}", exc_info=True)
        return jsonify({"error": str(e)}), 500

@app.route('/report')
def report():
    """Display the comparison report"""
    return render_template('report.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)