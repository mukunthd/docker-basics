from flask import Flask, render_template, request, jsonify
import boto3
import json
from datetime import datetime
from collections import defaultdict
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

class AWSResourceComparator:
    def __init__(self, profile_a, profile_b, regions=None):
        """Initialize with AWS profiles for both accounts"""
        self.profile_a = profile_a
        self.profile_b = profile_b
        self.regions = regions or ['us-east-1', 'us-west-2', 'eu-west-1']  # Default regions
        self.session_a = boto3.Session(profile_name=profile_a)
        self.session_b = boto3.Session(profile_name=profile_b)
        
    def get_tagged_resources(self, session, tag_key, tag_value):
        """Get all resources with specific tag from an account across multiple regions"""
        all_resources = []
        
        for region in self.regions:
            try:
                resource_groups_client = session.client('resourcegroupstaggingapi', region_name=region)
                resources = []
                
                paginator = resource_groups_client.get_paginator('get_resources')
                for page in paginator.paginate(
                    TagFilters=[
                        {
                            'Key': tag_key,
                            'Values': [tag_value]
                        }
                    ]
                ):
                    resources.extend(page['ResourceTagMappingList'])
                
                # Add region info to each resource for tracking
                for resource in resources:
                    resource['Region'] = region
                
                all_resources.extend(resources)
                logging.info(f"Found {len(resources)} resources in region {region}")
                
            except Exception as e:
                logging.error(f"Error fetching resources from region {region}: {e}")
                continue
                
        return all_resources
    
    def get_resource_details(self, session, resource_arn):
        """Get detailed information about a specific resource"""
        service = resource_arn.split(':')[2]
        region = resource_arn.split(':')[3]
        resource_id = resource_arn.split('/')[-1]
        
        # Handle S3 which doesn't have region in ARN
        if service == 's3':
            region = 'us-east-1'  # S3 API calls typically go to us-east-1
        elif not region:
            region = 'us-east-1'  # Default region if not specified
        
        try:
            if service == 'lambda':
                return self._get_lambda_details(session, resource_arn, region)
            elif service == 's3':
                return self._get_s3_details(session, resource_arn)
            elif service == 'elasticloadbalancing':
                return self._get_alb_details(session, resource_arn, region)
            elif service == 'apigateway':
                return self._get_apigateway_details(session, resource_arn, region)
            elif service == 'ec2':
                return self._get_ec2_details(session, resource_arn, region)
        except Exception as e:
            logging.error(f"Error getting details for {resource_arn}: {e}")
            return {"error": str(e)}
        
        return {"service": service, "details": "Details not implemented for this service"}
    
    def _get_lambda_details(self, session, resource_arn, region):
        """Get Lambda function details including triggers"""
        lambda_client = session.client('lambda', region_name=region)
        function_name = resource_arn.split(':')[-1]
        
        try:
            # Get function configuration
            function_config = lambda_client.get_function(FunctionName=function_name)
            
            # Get event source mappings (triggers)
            event_sources = lambda_client.list_event_source_mappings(FunctionName=function_name)
            
            # Get function policy to identify other triggers
            try:
                policy = lambda_client.get_policy(FunctionName=function_name)
                policy_doc = json.loads(policy['Policy'])
            except:
                policy_doc = None
            
            return {
                "type": "lambda",
                "config": function_config['Configuration'],
                "code": function_config.get('Code', {}),
                "triggers": event_sources['EventSourceMappings'],
                "policy": policy_doc,
                "dependencies": self._get_lambda_dependencies(session, function_config, region)
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _get_lambda_dependencies(self, session, function_config, region):
        """Get Lambda dependencies like VPC, security groups, etc."""
        dependencies = {}
        
        # VPC Configuration
        if 'VpcConfig' in function_config['Configuration']:
            vpc_config = function_config['Configuration']['VpcConfig']
            if vpc_config.get('SecurityGroupIds'):
                dependencies['security_groups'] = self._get_security_group_details(
                    session, vpc_config['SecurityGroupIds'], region
                )
            if vpc_config.get('SubnetIds'):
                dependencies['subnets'] = vpc_config['SubnetIds']
        
        return dependencies
    
    def _get_security_group_details(self, session, sg_ids, region):
        """Get security group details and rules"""
        ec2_client = session.client('ec2', region_name=region)
        
        try:
            response = ec2_client.describe_security_groups(GroupIds=sg_ids)
            return response['SecurityGroups']
        except Exception as e:
            return {"error": str(e)}
    
    def _get_alb_details(self, session, resource_arn, region):
        """Get ALB details including listeners and target groups"""
        elbv2_client = session.client('elbv2', region_name=region)
        
        try:
            # Get load balancer details
            lb_response = elbv2_client.describe_load_balancers(LoadBalancerArns=[resource_arn])
            lb_details = lb_response['LoadBalancers'][0]
            
            # Get listeners
            listeners = elbv2_client.describe_listeners(LoadBalancerArn=resource_arn)
            
            # Get target groups
            target_groups = elbv2_client.describe_target_groups(LoadBalancerArn=resource_arn)
            
            # Get security groups
            sg_details = None
            if lb_details.get('SecurityGroups'):
                sg_details = self._get_security_group_details(
                    session, lb_details['SecurityGroups'], region
                )
            
            return {
                "type": "alb",
                "details": lb_details,
                "listeners": listeners['Listeners'],
                "target_groups": target_groups['TargetGroups'],
                "security_groups": sg_details
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _get_s3_details(self, session, resource_arn):
        """Get S3 bucket details"""
        s3_client = session.client('s3')
        bucket_name = resource_arn.split(':')[-1]
        
        try:
            # Get bucket location
            location = s3_client.get_bucket_location(Bucket=bucket_name)
            
            # Get bucket policy
            try:
                policy = s3_client.get_bucket_policy(Bucket=bucket_name)
                policy_doc = json.loads(policy['Policy'])
            except:
                policy_doc = None
            
            # Get bucket versioning
            try:
                versioning = s3_client.get_bucket_versioning(Bucket=bucket_name)
            except:
                versioning = None
            
            return {
                "type": "s3",
                "bucket_name": bucket_name,
                "location": location,
                "policy": policy_doc,
                "versioning": versioning
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _get_apigateway_details(self, session, resource_arn, region):
        """Get API Gateway details"""
        apigateway_client = session.client('apigateway', region_name=region)
        api_id = resource_arn.split('/')[-1]
        
        try:
            # Get REST API details
            api_details = apigateway_client.get_rest_api(restApiId=api_id)
            
            # Get resources
            resources = apigateway_client.get_resources(restApiId=api_id)
            
            # Get stages
            stages = apigateway_client.get_stages(restApiId=api_id)
            
            return {
                "type": "apigateway",
                "api_details": api_details,
                "resources": resources['items'],
                "stages": stages['item']
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _get_ec2_details(self, session, resource_arn, region):
        """Get EC2 instance details"""
        ec2_client = session.client('ec2', region_name=region)
        instance_id = resource_arn.split('/')[-1]
        
        try:
            response = ec2_client.describe_instances(InstanceIds=[instance_id])
            instance = response['Reservations'][0]['Instances'][0]
            
            # Get security group details
            sg_details = None
            if instance.get('SecurityGroups'):
                sg_ids = [sg['GroupId'] for sg in instance['SecurityGroups']]
                sg_details = self._get_security_group_details(session, sg_ids, region)
            
            return {
                "type": "ec2",
                "instance": instance,
                "security_groups": sg_details
            }
        except Exception as e:
            return {"error": str(e)}
    
    def compare_resources(self, tag_key, tag_value):
        """Compare resources between two accounts"""
        # Get resources from both accounts
        resources_a = self.get_tagged_resources(self.session_a, tag_key, tag_value)
        resources_b = self.get_tagged_resources(self.session_b, tag_key, tag_value)
        
        # Organize by service type
        comparison = {
            "account_a": {
                "profile": self.profile_a,
                "resources": self._organize_by_service(resources_a)
            },
            "account_b": {
                "profile": self.profile_b,
                "resources": self._organize_by_service(resources_b)
            },
            "summary": self._generate_summary(resources_a, resources_b)
        }
        
        return comparison
    
    def _organize_by_service(self, resources):
        """Organize resources by AWS service"""
        organized = defaultdict(list)
        
        for resource in resources:
            arn = resource['ResourceARN']
            service = arn.split(':')[2]
            region = resource.get('Region', arn.split(':')[3] if len(arn.split(':')) > 3 else 'global')
            
            organized[service].append({
                "arn": arn,
                "region": region,
                "tags": {tag['Key']: tag['Value'] for tag in resource['Tags']}
            })
        
        return dict(organized)
    
    def _generate_summary(self, resources_a, resources_b):
        """Generate comparison summary"""
        services_a = set(res['ResourceARN'].split(':')[2] for res in resources_a)
        services_b = set(res['ResourceARN'].split(':')[2] for res in resources_b)
        
        regions_a = set(res.get('Region', 'unknown') for res in resources_a)
        regions_b = set(res.get('Region', 'unknown') for res in resources_b)
        
        return {
            "total_resources_a": len(resources_a),
            "total_resources_b": len(resources_b),
            "services_a": list(services_a),
            "services_b": list(services_b),
            "regions_a": list(regions_a),
            "regions_b": list(regions_b),
            "common_services": list(services_a & services_b),
            "only_in_a": list(services_a - services_b),
            "only_in_b": list(services_b - services_a),
            "common_regions": list(regions_a & regions_b),
            "regions_only_in_a": list(regions_a - regions_b),
            "regions_only_in_b": list(regions_b - regions_a)
        }

# Flask routes
@app.route('/')
def index():
    """Main page with form to input parameters"""
    return render_template('index.html')

@app.route('/compare', methods=['POST'])
def compare():
    """Generate comparison report"""
    data = request.get_json()
    
    profile_a = data.get('profile_a')
    profile_b = data.get('profile_b')
    tag_key = data.get('tag_key', 'Component')
    tag_value = data.get('tag_value', 'testing')
    regions = data.get('regions', ['us-east-1', 'us-west-2', 'eu-west-1'])
    
    if not profile_a or not profile_b:
        return jsonify({"error": "Both AWS profiles are required"}), 400
    
    try:
        comparator = AWSResourceComparator(profile_a, profile_b, regions)
        comparison_result = comparator.compare_resources(tag_key, tag_value)
        
        return jsonify({
            "success": True,
            "data": comparison_result,
            "timestamp": datetime.now().isoformat()
        })
    except Exception as e:
        logging.error(f"Comparison error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/resource-details')
def resource_details():
    """Get detailed information about a specific resource"""
    resource_arn = request.args.get('arn')
    profile = request.args.get('profile')
    
    logging.info(f"Resource details request - ARN: {resource_arn}, Profile: {profile}")
    
    if not resource_arn or not profile:
        logging.error("Missing required parameters")
        return jsonify({"error": "Resource ARN and profile are required"}), 400
    
    try:
        session = boto3.Session(profile_name=profile)
        comparator = AWSResourceComparator(profile, profile)
        details = comparator.get_resource_details(session, resource_arn)
        
        logging.info(f"Resource details retrieved: {type(details)}")
        logging.debug(f"Details content: {details}")
        
        response = {
            "success": True,
            "data": details
        }
        
        logging.info(f"Sending response: success={response['success']}")
        return jsonify(response)
        
    except Exception as e:
        logging.error(f"Resource details error: {e}", exc_info=True)
        return jsonify({"error": str(e)}), 500

@app.route('/report')
def report():
    """Display the comparison report"""
    return render_template('report.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)