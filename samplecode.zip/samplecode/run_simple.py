#!/usr/bin/env python3
"""
Simple startup script for SSL issues - no proxy configuration needed
"""

import os
import sys

def main():
    print("🔧 Configuring for SSL/firewall issues...")
    
    # Just disable SSL verification - no proxy needed
    os.environ['DISABLE_SSL_VERIFICATION'] = 'true'
    os.environ['PYTHONHTTPSVERIFY'] = '0'
    
    print("✅ SSL verification disabled")
    print("🚀 Starting application...")
    
    try:
        from app import app
        app.run(debug=True, host='0.0.0.0', port=5000)
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()